package webcaisse.model;

public class VenteEcommerce /*extends Vente*/ {

    private String adresseLivraison;
    private String optionLivraison;
}
