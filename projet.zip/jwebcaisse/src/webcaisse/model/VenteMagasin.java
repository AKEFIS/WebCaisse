package webcaisse.model;

public class VenteMagasin /*extends Vente*/ {
    private String matriculeVendeur;
    
}
