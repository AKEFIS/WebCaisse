
package webcaisse.DAO;
import java.util.HashMap;
import webcaisse.model.Commune;

public interface VilleDAOInterface {
    public static HashMap<Integer, Commune> villesPourCp(String codePostal) {
        HashMap<Integer, Commune> listVilles = new HashMap<>();
        // code à implémenter
        return listVilles;
    }

    
}
